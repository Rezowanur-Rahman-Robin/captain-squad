<?php

$con=mysqli_connect("localhost:3306","captains_admin","captainchamp2000gmail","captains_bn");

?>