<?php
$con=mysqli_connect("localhost:3306","captains_admin","captainchamp2000gmail","captains_bn");
 

mysqli_query($con,'SET CHARACTER SET utf8'); 

mysqli_query($con,"SET SESSION collation_connection ='utf8_general_ci'");

?>