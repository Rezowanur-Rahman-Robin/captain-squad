<?php

$con=mysqli_connect("localhost:3306","rtgblogc_admin","robin9638527","rtgblogc_bn");

?>