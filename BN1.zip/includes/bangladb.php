<?php
$con=mysqli_connect("localhost:3306","rtgblogc_admin","robin9638527","rtgblogc_bn");
 

mysqli_query($con,'SET CHARACTER SET utf8'); 

mysqli_query($con,"SET SESSION collation_connection ='utf8_general_ci'");

?>