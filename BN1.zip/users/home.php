<?php

include("includes/db.php");

?>

<?php 
    
    session_start();

    if(!isset( $_SESSION['u_phn'])){

        
        
        echo "<script>window.open('login.php','_self')</script>";
        
    }else{

        $u_phone=$_SESSION['u_phn'];

        $select_user="select * from users where u_phn='$u_phone'";

        $run_user=mysqli_query($con,$select_user);

       if($row_user=mysqli_fetch_array($run_user))
       {
           $u_id=$row_user['u_id'];
           $u_name=$row_user['u_name'];
           $u_image=$row_user['u_image'];
       }
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Panel</title>
    <link rel="shortcut icon" type="image/jpg" href="../images/f.jpg">
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <link rel="stylesheet" href="../font-awesome/css/all.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="styles/style.css">
</head>


<body>
<div id="home-bg">

<div class="row">

   <div class="ml-5 col-xs-8 welcome">

       <img src="images/<?php echo"$u_image"; ?>" alt="Student Profile Picture" class="img-responsive col-sm-4">
       
       <h3>Welcome</h3> <h4><?php  echo" $u_name";?></h4>
    </div>
   <div class="col-xs-4">
      <a href="logout.php" class="btn btn-lg btn-primary logout " >Log Out</a>
   </div>

</div>


<div class="heading"><h1>All Examinations List</h1><hr></div>
<div class="container"><!-- container begin -->

   <div class="row">
   <?php

$get_exam="select * from exam";
$run_exam=mysqli_query($con,$get_exam);
while($row_exam=mysqli_fetch_array($run_exam)){
          
      $exam_id=$row_exam['exam_id'];

      $exam_title=$row_exam['exam_title'];

      $total_questions=$row_exam['total_questions'];

      $exam_marks=$row_exam['exam_marks'];

      $exam_date=$row_exam['exam_date'];

      $exam_finish=$row_exam['exam_finish'];
     
      $duration=strtotime($exam_finish)-strtotime($exam_date);

      $min_duration=$duration/60;

?>
        <div class="col-sm-6">
              <div class="panel panel-default panel-primary">
                  <div class="panel-heading"><h2><?php echo"$exam_title";  ?></h2></div>
                  <div class="panel-body">

                        <div class="row">
                        <div class="col-sm-6 grad">
                        <span>   
                        <i class="fas fa-graduation-cap"></i>
                        
                        </div>
                        </span> 
                        <div class="col-sm-6 desc" >


                            <h3>Totat Questions: <?php echo"$total_questions";  ?></h3>
                            <h3>Total Marks: <?php echo"$exam_marks";  ?></h3>
                            <h3>Start Time: <?php   echo date('h:i:s A d/m/Y', strtotime($exam_date));  ?></h3>
                            <h3>Duration: <?php echo"$min_duration";  ?> Minutes</h3>

                         
                        </div>
                        </div>

                  </div>
                  <div class="panel-footer">

                  <a href="start.php?u_id=<?php echo"$u_id";?>&&exam_id=<?php echo"$exam_id";?>" class="btn btn-primary" style="width: 100%;">Click here to start the exam</a>
                  </div>
              </div>
        </div>

        <?php } ?>


        

   </div>




   </div><!-- container finish -->
 </div>

 <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    
</body>
</html>


<?php  } ?>